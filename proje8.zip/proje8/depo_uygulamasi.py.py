"""
============================================================
  PROJE 8: DEPO VE STOK YÖNETİM SİSTEMİ (Endüstriyel Tema)
============================================================
Açıklama: Bu proje, Depo ve Stok yönetimini Nesne Tabanlı Programlama (OOP) ile sağlar.
Kurulum  : pip install PyQt5
============================================================
"""
# GEREKLİ KÜTÜPHANELER
import sys
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QFrame,
    QStackedWidget, QHeaderView, QLineEdit, QGridLayout,
    QSpinBox, QDoubleSpinBox, QMessageBox,
    QAbstractItemView, QGraphicsDropShadowEffect
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor, QPalette, QFont

# ============================================================
#  1. KISIM: İŞ MANTIĞI VE SINIFLAR
# ============================================================
# NOT: Bu kısım tamamen OOP prensiplerine göre tasarlanmıştır ve GUI'den bağımsızdır.
class Urun:
    """Depodaki bir ürünü temsil eder."""
    def __init__(self, urun_id: int, ad: str, stok: int, fiyat: float): # Yapıcı metot (Constructor)
        self.__urun_id = urun_id
        self.__ad      = ad
        self.__stok    = stok
        self.__fiyat   = fiyat

    def get_urun_id(self) -> int:   return self.__urun_id
    def get_ad(self)      -> str:   return self.__ad
    def get_stok(self)    -> int:   return self.__stok
    def get_fiyat(self)   -> float: return self.__fiyat

    def stok_arttir(self, miktar: int):  #"Stok artırma işlemi"
        if miktar > 0:
            self.__stok += miktar
            return True, f"{self.__ad} stoğu arttırıldı. Yeni Stok: {self.__stok}"
        return False, "Miktar 0'dan büyük olmalı!"

    def stok_azalt(self, miktar: int): #"Stok azaltma işlemi"
        if miktar <= 0:
            return False, "Geçersiz miktar!"
        if self.__stok >= miktar:
            self.__stok -= miktar
            return True, f"{self.__ad} stoğundan {miktar} adet çıkış yapıldı. Kalan: {self.__stok}"
        return False, f"YETERSİZ STOK! Mevcut: {self.__stok}"
# DEPO SINIFI (STOKLARI VE SİPARİŞLERİ YÖNETİR)
class Siparis:  
    """Bir çıkış siparişini temsil eder."""
    def __init__(self, siparis_id: int, urun: Urun, adet: int):
        self.__siparis_id = siparis_id
        self.__urun       = urun
        self.__adet       = adet
        self.__tarih      = datetime.now()
        self.__toplam_fiyat = self.__urun.get_fiyat() * self.__adet
# Çıkış siparişi oluşturma işlemi
    def siparis_olustur(self): #"Çıkış siparişi oluşturma işlemi"
        basarili_mi, mesaj = self.__urun.stok_azalt(self.__adet)
        return basarili_mi, mesaj

    def get_siparis_id(self) -> int: return self.__siparis_id
    def get_urun(self)       -> Urun: return self.__urun
    def get_adet(self)       -> int: return self.__adet
    def get_toplam_fiyat(self) -> float: return self.__toplam_fiyat
    def get_tarih(self)      -> datetime: return self.__tarih
# DEPO MERKEZİ SINIFI (TÜM VERİLER BURADA TUTULUR)
class DepoMerkezi:
    """Tüm verileri tutan ana merkez."""
    def __init__(self):
        self.__urunler = {}      
        self.__siparisler = []   
        self.__son_siparis_id = 1000

    def urun_ekle(self, urun: Urun): #"Depoya yeni ürün ekleme işlemi"
        if urun.get_urun_id() in self.__urunler:
            return False, "Bu ID ile zaten bir ürün var."
        self.__urunler[urun.get_urun_id()] = urun
        return True, "Ürün depoya eklendi."

    def urun_getir(self, urun_id: int): #"Ürün getirme işlemi"
        return self.__urunler.get(urun_id, None)

    def get_tum_urunler(self) -> dict: #"Depodaki tüm ürünleri getirme işlemi"
        return self.__urunler

    def yeni_siparis(self, urun_id: int, adet: int): #"Yeni çıkış siparişi oluşturma işlemi"
        urun = self.urun_getir(urun_id)
        if not urun:
            return False, "Ürün bulunamadı!"
        
        yeni_sip = Siparis(self.__son_siparis_id, urun, adet) #Sipariş nesnesi oluşturuluyor
        ok, msg = yeni_sip.siparis_olustur()
        
        if ok:
            self.__siparisler.append(yeni_sip)
            self.__son_siparis_id += 1
            return True, "Sipariş Çıkışı Onaylandı!"
        return False, msg

    def get_siparisler(self) -> list: #"Depodaki tüm çıkış siparişlerini getirme işlemi"
        return self.__siparisler

# ============================================================
#  2. KISIM: ARAYÜZ (GUI) - ENDÜSTRİYEL DEPO TEMASI
# ============================================================

# YENİ RENK PALETİ: Koyu Gri ve Kehribar (Amber/Turuncu)
C = {
    "bg":        "#121212",  # Çok koyu arka plan
    "sidebar":   "#1E1E1E",  # Yan panel rengi
    "card":      "#252526",  # Kart arka planı
    "border":    "#333333",  # Kenarlıklar
    "accent":    "#FF9800",  # Turuncu/Kehribar (Vurgu)
    "accent2":   "#F57C00",  # Koyu Turuncu
    "success":   "#4CAF50",  # Yeşil
    "warning":   "#FFEB3B",  # Sarı
    "danger":    "#F44336",  # Kırmızı
    "text":      "#E0E0E0",  # Açık Gri Metin
    "text_sub":  "#9E9E9E",  # Orta Gri Alt Metin
    "text_dim":  "#757575",  # Koyu Gri Metin
    "row_alt":   "#1A1A1A",  # Tablo alternatif satır
    "row_sel":   "#3E2723",  # Seçili satır (Koyu kahve/turuncu tonu)
    "input_bg":  "#121212",  # Girdi alanı arka planı
}
 # STİL TANIMLARI
def card_ss(): return f"background:{C['card']};border:1px solid {C['border']};border-radius:12px;"
def btn_primary_ss(): return f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {C['accent2']},stop:1 {C['accent']});color:#121212;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}QPushButton:hover{{background:#FFB74D;}}"
def btn_success_ss(): return f"QPushButton{{background:{C['success']};color:#121212;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}"
def btn_danger_ss(): return f"QPushButton{{background:{C['danger']};color:#fff;border:none;border-radius:8px;padding:9px 20px;font-size:13px;font-weight:800;}}"
def input_ss(): return f"QLineEdit,QSpinBox,QDoubleSpinBox{{background:{C['input_bg']};color:{C['text']};border:1px solid {C['border']};border-radius:8px;padding:7px 10px;font-size:13px;}}"
 # TABLO STİLİ
TABLE_SS = f"""
    QTableWidget{{background:{C['card']};color:{C['text']};border:none;gridline-color:{C['border']};font-size:13px;selection-background-color:{C['row_sel']};outline:none;alternate-background-color:{C['row_alt']};}}
    QTableWidget::item{{padding:9px 13px;border-bottom:1px solid {C['border']};}}
    QHeaderView::section{{background:{C['sidebar']};color:{C['accent']};padding:9px 13px;border:none;border-bottom:2px solid {C['accent']};font-size:12px;font-weight:800;letter-spacing:1px;}}
"""
# GÖLGE EFEKTI FONKSİYONU
def shadow(widget):
    fx = QGraphicsDropShadowEffect(widget)
    fx.setBlurRadius(15); fx.setColor(QColor(0, 0, 0, 100)); fx.setOffset(0, 3)
    widget.setGraphicsEffect(fx)

class KpiCard(QFrame): # Gösterge kartı
    def __init__(self, baslik, deger, alt, renk):
        super().__init__()
        self.setFixedHeight(114)
        self.setStyleSheet(f"QFrame{{background:{C['card']};border:1px solid {C['border']};border-radius:13px;border-left:4px solid {renk};}}")
        shadow(self)
        lay = QVBoxLayout(self); lay.setContentsMargins(18, 12, 18, 12); lay.setSpacing(3)
        lbl_t = QLabel(baslik.upper()); lbl_t.setStyleSheet(f"color:{C['text_sub']};font-size:10px;font-weight:800;letter-spacing:1px;background:transparent;border:none;")
        self.lbl_v = QLabel(str(deger)); self.lbl_v.setStyleSheet(f"color:{renk};font-size:29px;font-weight:800;background:transparent;border:none;")
        lbl_a = QLabel(alt); lbl_a.setStyleSheet(f"color:{C['text_dim']};font-size:11px;background:transparent;border:none;")
        lay.addWidget(lbl_t); lay.addWidget(self.lbl_v); lay.addWidget(lbl_a)
    def guncelle(self, val): self.lbl_v.setText(str(val))

class SideBtn(QPushButton): # Yan menü butonu
    def __init__(self, ikon, metin):
        super().__init__(f"  {ikon}  {metin}")
        self.setCheckable(True); self.setFixedHeight(48); self.setCursor(Qt.PointingHandCursor)
        self._refresh(False)
    def _refresh(self, aktif):
        if aktif: self.setStyleSheet(f"QPushButton{{background:rgba(255,152,0,0.1);color:{C['accent']};border:none;border-left:3px solid {C['accent']};border-radius:0;text-align:left;padding-left:16px;font-size:13px;font-weight:800;}}")
        else: self.setStyleSheet(f"QPushButton{{background:transparent;color:{C['text_sub']};border:none;border-left:3px solid transparent;border-radius:0;text-align:left;padding-left:16px;font-size:13px;font-weight:600;}}QPushButton:hover{{background:{C['card']};color:{C['text']};border-left:3px solid {C['text_dim']};}}")
    def setChecked(self, v): super().setChecked(v); self._refresh(v)

class DashboardPage(QWidget): # Gösterge paneli
    def __init__(self, depo: DepoMerkezi):
        super().__init__()
        self.depo = depo
        lay = QVBoxLayout(self); lay.setContentsMargins(28, 22, 28, 22); lay.setSpacing(18)
        lbl = QLabel("📊  Depo Dashboard")
        lbl.setStyleSheet(f"color:{C['text']};font-size:21px;font-weight:800;")
        lay.addWidget(lbl)

        self.kpi_row = QHBoxLayout(); lay.addLayout(self.kpi_row)
        self.c1 = KpiCard("Toplam Ürün", 0, "Kayıtlı Barkod", C['accent'])
        self.c2 = KpiCard("Fiziksel Stok", 0, "Depodaki Adet", C['success'])
        self.c3 = KpiCard("Sipariş Çıkışı", 0, "Tamamlanan İşlem", C['warning'])
        for c in [self.c1, self.c2, self.c3]: self.kpi_row.addWidget(c)

        lay.addWidget(QLabel("Mevcut Depo Durumu", styleSheet=f"color:{C['text_sub']};font-size:12px;font-weight:800;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["ID", "Ürün Adı", "Mevcut Stok", "Fiyat"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def refresh(self):
        urunler = self.depo.get_tum_urunler().values()
        self.c1.guncelle(len(urunler))
        self.c2.guncelle(sum(u.get_stok() for u in urunler))
        self.c3.guncelle(len(self.depo.get_siparisler()))
        
        self.tablo.setRowCount(0)
        for u in urunler:
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(u.get_urun_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(u.get_ad()))
            
            stok_item = QTableWidgetItem(str(u.get_stok()))
            font = QFont(); font.setBold(True); stok_item.setFont(font)
            if u.get_stok() < 10: stok_item.setForeground(QColor(C['danger']))
            else: stok_item.setForeground(QColor(C['success']))
            self.tablo.setItem(r, 2, stok_item)
            
            self.tablo.setItem(r, 3, QTableWidgetItem(f"₺{u.get_fiyat():.2f}"))
# İTHALATÇI SINIFI (ÜRÜN FİYATINI DÖVİZ KURU VE GÜMRÜK ORANI İLE HESAPLAR)
class UrunPage(QWidget):
    def __init__(self, depo: DepoMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.depo = depo; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(28, 22, 28, 22); lay.setSpacing(16)
        lay.addWidget(QLabel("📦  Ürün ve Stok Yönetimi", styleSheet=f"color:{C['text']};font-size:21px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QVBoxLayout(kart); klay.setContentsMargins(22,18,22,18)
        klay.addWidget(QLabel("Yeni Ürün Tanımla", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        
        grid = QGridLayout()
        self.inp_id = QSpinBox(); self.inp_id.setRange(1, 9999)
        self.inp_ad = QLineEdit(); self.inp_ad.setPlaceholderText("örn. Anakart")
        self.inp_fiyat = QDoubleSpinBox(); self.inp_fiyat.setRange(0, 99999); self.inp_fiyat.setDecimals(2)
        self.inp_stok = QSpinBox(); self.inp_stok.setRange(0, 9999)
        for w in [self.inp_id, self.inp_ad, self.inp_fiyat, self.inp_stok]: w.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:11px;font-weight:800;background:transparent;"
        grid.addWidget(QLabel("Ürün ID", styleSheet=lbl_style), 0, 0); grid.addWidget(self.inp_id, 1, 0)
        grid.addWidget(QLabel("Ürün Adı", styleSheet=lbl_style), 0, 1); grid.addWidget(self.inp_ad, 1, 1)
        grid.addWidget(QLabel("Fiyat (₺)", styleSheet=lbl_style), 0, 2); grid.addWidget(self.inp_fiyat, 1, 2)
        grid.addWidget(QLabel("Başlangıç Stok", styleSheet=lbl_style), 0, 3); grid.addWidget(self.inp_stok, 1, 3)
        klay.addLayout(grid)
        
        btn_ekle = QPushButton("＋  Ürün Ekle"); btn_ekle.setStyleSheet(btn_primary_ss()); btn_ekle.clicked.connect(self._ekle)
        klay.addWidget(btn_ekle)
        lay.addWidget(kart)

        kart2 = QFrame(); kart2.setStyleSheet(card_ss()); shadow(kart2)
        k2lay = QHBoxLayout(kart2); k2lay.setContentsMargins(22,16,22,16)
        k2lay.addWidget(QLabel("Stoğa Mal Ekle:", styleSheet=f"color:{C['success']};font-size:13px;font-weight:800;background:transparent;"))
        self.g_id = QSpinBox(); self.g_id.setRange(1, 9999); self.g_id.setStyleSheet(input_ss())
        self.g_miktar = QSpinBox(); self.g_miktar.setRange(1, 9999); self.g_miktar.setStyleSheet(input_ss())
        k2lay.addWidget(QLabel("Ürün ID:", styleSheet=lbl_style)); k2lay.addWidget(self.g_id)
        k2lay.addWidget(QLabel("Adet:", styleSheet=lbl_style)); k2lay.addWidget(self.g_miktar)
        btn_arttir = QPushButton("▲ Stoğa Ekle"); btn_arttir.setStyleSheet(btn_success_ss()); btn_arttir.clicked.connect(self._arttir)
        k2lay.addWidget(btn_arttir); k2lay.addStretch()
        lay.addWidget(kart2)

        # EKSİK OLAN TABLO BURAYA EKLENDİ
        lay.addWidget(QLabel("Mevcut Ürünler", styleSheet=f"color:{C['text_sub']};font-size:12px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget()
        self.tablo.setColumnCount(4)
        self.tablo.setHorizontalHeaderLabels(["ID", "Ürün Adı", "Stok", "Fiyat"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS)
        self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        
        self.refresh()
# Ürün ekleme, stok artırma ve tablo yenileme fonksiyonları
    def refresh(self):
        self.tablo.setRowCount(0)
        urunler = self.depo.get_tum_urunler().values()
        for u in urunler:
            r = self.tablo.rowCount()
            self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(str(u.get_urun_id())))
            self.tablo.setItem(r, 1, QTableWidgetItem(u.get_ad()))
            
            stok_item = QTableWidgetItem(str(u.get_stok()))
            font = QFont(); font.setBold(True); stok_item.setFont(font)
            if u.get_stok() < 10: stok_item.setForeground(QColor(C['danger']))
            else: stok_item.setForeground(QColor(C['text']))
            self.tablo.setItem(r, 2, stok_item)
            
            self.tablo.setItem(r, 3, QTableWidgetItem(f"₺{u.get_fiyat():.2f}"))

    def _ekle(self):
        yeni_urun = Urun(self.inp_id.value(), self.inp_ad.text(), self.inp_stok.value(), self.inp_fiyat.value())
        ok, msg = self.depo.urun_ekle(yeni_urun)
        QMessageBox.information(self, "Bilgi", msg)
        if ok: 
            self.refresh()
            self.dashboard.refresh()

    def _arttir(self):
        urun = self.depo.urun_getir(self.g_id.value())
        if urun:
            ok, msg = urun.stok_arttir(self.g_miktar.value())
            QMessageBox.information(self, "Bilgi", msg)
            if ok: 
                self.refresh()
                self.dashboard.refresh()
        else:
            QMessageBox.warning(self, "Hata", "Ürün Bulunamadı!")
# URUN SAYFASI VE SİPARİŞ SAYFASI
class SiparisPage(QWidget):
    def __init__(self, depo: DepoMerkezi, dashboard: DashboardPage):
        super().__init__()
        self.depo = depo; self.dashboard = dashboard
        lay = QVBoxLayout(self); lay.setContentsMargins(28, 22, 28, 22); lay.setSpacing(16)
        lay.addWidget(QLabel("🚚  Sipariş Çıkışı", styleSheet=f"color:{C['text']};font-size:21px;font-weight:800;"))

        kart = QFrame(); kart.setStyleSheet(card_ss()); shadow(kart)
        klay = QHBoxLayout(kart); klay.setContentsMargins(22,18,22,18)
        klay.addWidget(QLabel("Yeni Sipariş Geç:", styleSheet=f"color:{C['accent']};font-size:13px;font-weight:800;background:transparent;"))
        self.s_id = QSpinBox(); self.s_id.setRange(1, 9999); self.s_id.setStyleSheet(input_ss())
        self.s_adet = QSpinBox(); self.s_adet.setRange(1, 9999); self.s_adet.setStyleSheet(input_ss())
        
        lbl_style = f"color:{C['text_sub']};font-size:11px;font-weight:800;background:transparent;"
        klay.addWidget(QLabel("Ürün ID:", styleSheet=lbl_style)); klay.addWidget(self.s_id)
        klay.addWidget(QLabel("Adet:", styleSheet=lbl_style)); klay.addWidget(self.s_adet)
        
        btn_satis = QPushButton("▼ Depodan Çıkış Yap"); btn_satis.setStyleSheet(btn_danger_ss()); btn_satis.clicked.connect(self._satis)
        klay.addWidget(btn_satis); klay.addStretch()
        lay.addWidget(kart)

        lay.addWidget(QLabel("Çıkan Siparişler Geçmişi", styleSheet=f"color:{C['text_sub']};font-size:12px;font-weight:800;margin-top:10px;"))
        self.tablo = QTableWidget(); self.tablo.setColumnCount(5)
        self.tablo.setHorizontalHeaderLabels(["Sip. No", "Tarih", "Ürün", "Adet", "Toplam Fiyat"])
        self.tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tablo.setStyleSheet(TABLE_SS); self.tablo.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tablo.verticalHeader().setVisible(False)
        lay.addWidget(self.tablo)
        self.refresh()

    def _satis(self):
        ok, msg = self.depo.yeni_siparis(self.s_id.value(), self.s_adet.value())
        QMessageBox.information(self, "İşlem Sonucu", msg)
        if ok: 
            self.refresh()
            self.dashboard.refresh()
            
            # Sipariş çıkışından sonra Ürünler sayfasındaki tablonun da güncellenmesi için:
            if hasattr(self.parentWidget().parentWidget(), 'p_urun'):
                self.parentWidget().parentWidget().p_urun.refresh()

    def refresh(self):
        self.tablo.setRowCount(0)
        for s in reversed(self.depo.get_siparisler()):
            r = self.tablo.rowCount(); self.tablo.insertRow(r)
            self.tablo.setItem(r, 0, QTableWidgetItem(f"#{s.get_siparis_id()}"))
            self.tablo.setItem(r, 1, QTableWidgetItem(s.get_tarih().strftime("%H:%M")))
            self.tablo.setItem(r, 2, QTableWidgetItem(s.get_urun().get_ad()))
            self.tablo.setItem(r, 3, QTableWidgetItem(str(s.get_adet())))
            
            tutar_item = QTableWidgetItem(f"₺{s.get_toplam_fiyat():.2f}")
            tutar_item.setForeground(QColor(C['accent']))
            self.tablo.setItem(r, 4, tutar_item)
# SİPARİŞ SAYFASI
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("📦  Proje 8 — Endüstriyel Depo Yönetimi")
        self.setMinimumSize(1150, 700); self.setStyleSheet(f"QMainWindow{{background:{C['bg']};color:{C['text']};}}")

        self.depo = DepoMerkezi()
        # Test Verileri
        self.depo.urun_ekle(Urun(1, "Çelik Raf Sistemi", 50, 1200.0))
        self.depo.urun_ekle(Urun(2, "Palet (Ahşap)", 200, 150.0))

        merkez = QWidget(); merkez.setStyleSheet(f"background:{C['bg']};"); self.setCentralWidget(merkez)
        ana = QHBoxLayout(merkez); ana.setContentsMargins(0, 0, 0, 0); ana.setSpacing(0)

        sidebar = QFrame(); sidebar.setFixedWidth(230); sidebar.setStyleSheet(f"background:{C['sidebar']};border-right:1px solid {C['border']};")
        sb = QVBoxLayout(sidebar); sb.setContentsMargins(0, 0, 0, 18); sb.setSpacing(0)
        
        logo = QFrame(); logo.setFixedHeight(76); logo.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {C['accent2']},stop:1 {C['accent']});")
        ll = QVBoxLayout(logo); ll.setContentsMargins(16, 10, 16, 10)
        t1 = QLabel("📦  Depo Sistemi"); t1.setStyleSheet("color:#121212;font-size:16px;font-weight:800;background:transparent;")
        t2 = QLabel("Proje 8"); t2.setStyleSheet("color:rgba(18,18,18,0.8);font-size:11px;font-weight:700;background:transparent;")
        ll.addWidget(t1); ll.addWidget(t2); sb.addWidget(logo); sb.addSpacing(18)

        self.nav = []
        for ikon, metin in [("📊", "Dashboard"), ("📦", "Ürünler"), ("🚚", "Sipariş")]:
            btn = SideBtn(ikon, metin); btn.clicked.connect(lambda _, m=metin: self._goto(m))
            sb.addWidget(btn); self.nav.append(btn)
        sb.addStretch()
        
        self.lbl_saat = QLabel(); self.lbl_saat.setAlignment(Qt.AlignCenter); self.lbl_saat.setStyleSheet(f"color:{C['text_dim']};font-size:11px;font-weight:700;background:transparent;")
        sb.addWidget(self.lbl_saat); ana.addWidget(sidebar)

        icerik = QWidget(); icerik.setStyleSheet(f"background:{C['bg']};")
        il = QVBoxLayout(icerik); il.setContentsMargins(0,0,0,0); il.setSpacing(0)

        topbar = QFrame(); topbar.setFixedHeight(50); topbar.setStyleSheet(f"background:{C['sidebar']};border-bottom:1px solid {C['border']};")
        tl = QHBoxLayout(topbar); tl.setContentsMargins(22, 0, 22, 0)
        self.lbl_page = QLabel("Dashboard"); self.lbl_page.setStyleSheet(f"color:{C['text_sub']};font-size:13px;font-weight:800;background:transparent;")
        tl.addWidget(self.lbl_page); tl.addStretch()
        tl.addWidget(QLabel("👤 Yönetici", styleSheet=f"color:{C['text_sub']};font-size:12px;font-weight:700;background:transparent;"))
        il.addWidget(topbar)

        self.stack = QStackedWidget(); self.stack.setStyleSheet(f"background:{C['bg']};")
        self.p_dashboard = DashboardPage(self.depo)
        self.p_urun = UrunPage(self.depo, self.p_dashboard)
        self.p_siparis = SiparisPage(self.depo, self.p_dashboard)
        for p in [self.p_dashboard, self.p_urun, self.p_siparis]: self.stack.addWidget(p)
        il.addWidget(self.stack); ana.addWidget(icerik)

        self._goto("Dashboard")
        t = QTimer(self); t.timeout.connect(lambda: self.lbl_saat.setText(datetime.now().strftime("%d.%m.%Y\n%H:%M:%S"))); t.start(1000)

    def _goto(self, sayfa):
        idx = {"Dashboard": 0, "Ürünler": 1, "Sipariş": 2}[sayfa]
        self.stack.setCurrentIndex(idx)
        self.lbl_page.setText(sayfa)
        for i, b in enumerate(self.nav): b.setChecked(i == idx)
        
        # Sayfaya giderken o sayfanın tablosunu yenile
        if idx == 0: self.p_dashboard.refresh()
        elif idx == 1: self.p_urun.refresh()
        elif idx == 2: self.p_siparis.refresh()
   
if __name__ == "__main__": # Uygulama Başlatma
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    p = QPalette()
    p.setColor(QPalette.Window, QColor(C['bg'])); p.setColor(QPalette.WindowText, QColor(C['text']))
    p.setColor(QPalette.Base, QColor(C['card'])); p.setColor(QPalette.AlternateBase, QColor(C['row_alt']))
    p.setColor(QPalette.Text, QColor(C['text'])); p.setColor(QPalette.Button, QColor(C['card']))
    p.setColor(QPalette.ButtonText, QColor(C['text'])); p.setColor(QPalette.Highlight, QColor(C['accent']))
    p.setColor(QPalette.HighlightedText, QColor("#121212"))
    app.setPalette(p)
    win = MainWindow(); win.show()
    sys.exit(app.exec_())